# Микроәлемге саяхат 🔬
GitHub Pages-қа дайын ықшамдалған нұсқа.

## Іске қосу
1. `index.html` және `README.md` файлдарын repository-ге жүктеңіз.
2. Settings → Pages.
3. Deploy from a branch → `main` → `/ (root)` → Save.
